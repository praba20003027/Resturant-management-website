//external package import
const express=require('express')
const bodypasrser=require('body-parser')
const mongoose=require('mongoose')
const cors=require('cors')
//internal file import

//const slashRoutes=require('./routes/slash')
const resturantRoutes=require('./routes/resturant')
const locationRoutes=require('./routes/location')
const mealtypeRoutes=require('./routes/mealtype')
const MONGO_URI="mongodb://localhost:27017/zomato_30"
const menuRoutes=require('./routes/menu')
mongoose.set('strictQuery', true);

//constant decleration
const PORT=9090;
const app=express()

const Resturants=require('./models/resturant')
app.get('/',(req,res)=>{
    Resturants.find()
    .then(
     result=>
     res.status(200).json({
         message:"resturant fetched succesfully",
         data:result
     })
    )
    .catch(
     error=>
     res.status(500).json({
         message:"db error occures",
         error:error
     })
    )
});

//connect to mongodb

mongoose.connect(MONGO_URI,()=>{
    console.log("mongodbs connected")
},
e=>console.log(e))

//creating decleration
//adding middleware

//app.use('/',slashRoutes)
app.use(cors())
app.use(bodypasrser.json())
app.use('/resturants',resturantRoutes)
app.use('/location',locationRoutes)
app.use('/mealtype',mealtypeRoutes)
app.use('/menu',menuRoutes)




app.listen(PORT,()=>{
    console.log(`the app has started on port:${PORT} `)
})
    
