const Loctions=require('../models/location')


exports.getAllLoctions=(req,res)=>{
    Loctions.find()
   .then(
    result=>
    res.status(200).json({
        message:"Loctions fetched succesfully",
        data:result
    })
   )
   .catch(
    error=>
    res.status(500).json({
        message:"db error occures",
        error:error
    })
    
    
   )}
   


