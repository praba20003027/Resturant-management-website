const Menu=require('../models/menu')


exports.getAllMenu=(req,res)=>{
    const rName=req.params.rname
    //console.log('rName:',rName)
    Menu.find({restaurantName:rName})
   .then(
    result=>
    res.status(200).json({
        message:"Menu fetched succesfully",
        data:result
    })
   )
   .catch(
    error=>
    res.status(500).json({
        message:"db error occures",
        error:error
    })
    
    
   )}
   