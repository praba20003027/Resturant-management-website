const Resturants=require('../models/resturant')


exports.getAllResturants=(req,res)=>{
    Resturants.find()
   .then(
    result=>
    res.status(200).json({
        message:"resturant fetched succesfully",
        data:result
    })
   )
   .catch(
    error=>
    res.status(500).json({
        message:"db error occures",
        error:error
    })
    
    
   )}
   
exports.getResturantByname=(req,res)=>{
    const criteria={
        name:req.params.name
    }
    Resturants.find(criteria)
    .then(
     result=>
     res.status(200).json({
         message:"resturant fetched succesfully",
         data:result
     })
    )
    .catch(
     error=>
     res.status(500).json({
         message:"db error occures",
         error:error
     })
     
     
    )}

//addby city

    exports.getResturantBycity=(req,res)=>{
        let filter={
            city:req.params.cID
        }
        Resturants.find(filter)
        .then(
         result=>
         res.status(200).json({
             message:"resturant fetched succesfully",
             data:result
         })
        )
        .catch(
         error=>
         res.status(500).json({
             message:"db error occures",
             error:error
         })
         
         
        )}


        //getresturantbyfilter

        exports.getResturantByfilter= (req,res)=>{
            let filter={

            }
            if(req.body.city_id)
            filter.city=req,body.city_id
            

            
            if(req.body.Cuisine && req.body.Cuisine.length >0)
            {
                filter['(Cuisine.name)']={$in:req.body.Cuisine}
            }
            //costing

            if(req.body.lcost && req.body.hcost){
                filter.cost={
                    $lt:req.body.hcost,
                    $gt:req.body.lcost
                }
            }
           // console.log("with filter")
            Resturants.find(filter).limit(2).skip(2*(req.params.pageNo-1)).sort({cost:req.body.sort})  
                                                                                                                                                                                                                                                       
            .then(
             result=>{
                Resturants.find(filter).count((err,count)=>{
                    if(err)
                    console.log(err);
                    else
                    res.status(200).json({
                        message:"resturant fetched succesfully",
                        data:result,
                        totalRestaurants:count
                    }) 

                })
                
                })

             
           
            
            .catch(
             error=>
             res.status(500).json({
                 message:"db error occures",
                 error:error
             })
             
             
            )}
            exports.getResturantByCity=(req,res)=>{
                Resturants.find({city:req.params.id})
                .then(
                 result=>
                 res.status(200).json({
                     message:"resturant fetched succesfully",
                     data:result
                 })
                )
                .catch(
                 error=>
                 res.status(500).json({
                     message:"db error occures",
                     error:error
                 })
                 
                 
                )}

            
    



    