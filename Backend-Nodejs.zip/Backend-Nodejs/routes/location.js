const express=require('express')

const locationController=require('../controller/location')

const router=express.Router()


router.get('/',locationController.getAllLoctions)
//router.get('/:name',resturantController.getResturantByname)
//router.get('/:cID',resturantController.getResturantBycity)
//router.post('/filter/:pageNo',resturantController.getResturantByfilter)

//router.post('/',resturantController.addResturant)
//router.put('/',resturantController.updateresturant)
//router.delete('/',resturantController.deleteresturant)
module.exports=router;