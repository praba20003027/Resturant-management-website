const express=require('express')

const mealtypeController=require('../controller/mealtype')

const router=express.Router()


router.get('/',mealtypeController.getAllMealtypes)
//router.get('/:name',resturantController.getResturantByname)
//router.get('/:cID',resturantController.getResturantBycity)
//router.post('/filter/:pageNo',resturantController.getResturantByfilter)

//router.post('/',resturantController.addResturant)
//router.put('/',resturantController.updateresturant)
//router.delete('/',resturantController.deleteresturant)
module.exports=router;