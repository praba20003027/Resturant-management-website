const express=require('express')

const resturantController=require('../controller/resturant')

const router=express.Router()
router.get('/city/:id',resturantController.getResturantByCity)

router.get('/',resturantController.getAllResturants)
router.get('/:name',resturantController.getResturantByname)
//router.get('/:cID',resturantController.getResturantBycity)
router.post('/filter/:pageNo',resturantController.getResturantByfilter)

//router.post('/',resturantController.addResturant)
//router.put('/',resturantController.updateresturant)
//router.delete('/',resturantController.deleteresturant)
module.exports=router;